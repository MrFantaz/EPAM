package util;

import flower.Flower;
import model.Order;

public interface  FlowerInterface {
     Order addFlower(Flower flowerInterface, int quantity);
        }
